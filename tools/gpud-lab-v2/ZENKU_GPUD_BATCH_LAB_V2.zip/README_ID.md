# ZENKU GPUD Batch Lab V2

Penguji lokal satu-perintah untuk Android 13 / MediaTek MT6789 / Mali-G57 MC2.
Tidak membuat APK dan tidak mengubah konfigurasi boot ZENKU. Probe C memakai
EGL/GLES Android dari path sistem, bukan Mesa Termux.

## Jalankan

1. Ekstrak ZIP menjadi satu folder di Termux.
2. Pastikan Magisk root aktif dan tidak ada game yang sedang berjalan.
3. Jalankan:

```bash
chmod +x gpud_batch_v2.sh
./gpud_batch_v2.sh
```

Script memasang `clang` dan `binutils` bila belum ada, mengompilasi `gpud_probe.c`
satu kali, lalu menjalankan seluruh skenario yang memenuhi pemeriksaan fingerprint
serta string properti. Hasil berada di `~/zenku-gpud-lab-v2-results/`.

## Yang diuji

- Baseline normal dan EGL low-colour (RGB565) untuk pembanding.
- AF 4x / 16x dan trilinear melalui GL state readback.
- Force RGBA8888 dalam dua skenario: properti force saja, lalu force + EGL
  choose-config, keduanya memakai permintaan low-colour agar perubahan terlihat.
- Native MSAA 4x melalui EGLConfig dan `GL_SAMPLES`.
- Scissor dan Viewport untuk dua namespace yang ditemukan di binary:
  `vendor.debug.gpud.gl.scissor.*` / `vendor.debug.gpud.gl.viewport.*` dan
  `debug.gpu.glscissor.*` / `debug.gpu.glviewport.*`.
- Shader Source, FBC, dan Highp tetap dilaporkan secara konservatif ketika
  tidak tersedia bukti driver-level yang cukup.

## Scissor / Viewport

Probe memanggil `glScissor(13,17,111,119)` dan
`glViewport(7,11,123,137)`. Batch memberi sentinel yang berbeda:

- Scissor: `31,37,149,151`
- Viewport: `23,29,157,163`

Status `OVERRIDE_READBACK_OBSERVED` hanya diberikan jika keempat nilai hasil
`glGetIntegerv(GL_SCISSOR_BOX / GL_VIEWPORT)` sama persis dengan sentinel.
Status tersebut membuktikan efek pada state OpenGL proses penguji, bukan bahwa
pengaturan aman atau bermanfaat untuk seluruh game. Hasil yang berbeda dilabeli
`NO_OVERRIDE_READBACK`; skenario yang tidak ditemukan / gagal menulis akan
`SKIPPED`.

## Proteksi dan batas interpretasi

- Properti yang mungkin disentuh di-snapshot ke `properties.before.tsv`.
- Properti dipulihkan ketika script selesai atau dihentikan dengan Ctrl+C/TERM.
- Mutasi fitur hanya dilakukan jika SDK, platform, SHA-256 `libgpud.so`, SHA-256
  Mali, dan pemetaan library pada proses penguji cocok dengan fingerprint ZENKU.
- Proses target sementara bernama `gpulab`, bukan game. Tutup game dahulu.
- Nama properti harus ditemukan di string binary. String yang ditemukan bukan
  bukti bahwa properti dikonsumsi.
- EGLConfig membuktikan format konfigurasi terpilih, bukan format seluruh
  surface aplikasi. MSAA readback hanya berlaku untuk Pbuffer penguji.
- AF/trilinear readback menunjukkan nilai state yang efektif. Itu bukan bukti
  peningkatan FPS.
- FBC dan Highp tidak diklaim berhasil hanya dari property readback atau
  precision capability query.
- Jika fingerprint berbeda atau library tak terpetakan, mutasi dilewati.

Laporan utama: `SUMMARY.txt`; detail per-skenario: file `.log` di folder hasil.
