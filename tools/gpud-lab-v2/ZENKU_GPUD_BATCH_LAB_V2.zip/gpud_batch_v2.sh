#!/data/data/com.termux/files/usr/bin/bash
# ZENKU GPUD Batch Laboratory V2 — batch diagnostics for texture, EGL, scissor and viewport hooks.
# It only toggles properties after matching the ROM's known driver fingerprints
# and seeing the relevant property strings in the actual vendor binaries.
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date '+%Y%m%d_%H%M%S')"
OUT_DIR="${HOME}/zenku-gpud-lab-v2-results/${STAMP}"
WORK_DIR="${HOME}/.cache/zenku-gpud-lab-v2"
mkdir -p "$OUT_DIR" "$WORK_DIR"
REPORT="$OUT_DIR/SUMMARY.txt"
BACKUP="$OUT_DIR/properties.before.tsv"
KEYS="$OUT_DIR/property_strings.txt"
SOURCES="$OUT_DIR/property_sources.tsv"

GPUD_LIB=/vendor/lib64/libgpud.so
MALI_LIB=/vendor/lib64/egl/mt6789/libGLES_mali.so
EXPECTED_GPUD_SHA=561f84e37814769b85facb52e330753db34ada69edac9dfe15573485bd8b8712
EXPECTED_MALI_SHA=f1fb52d820be0a14baaeab7bf4ed9781c6be42470397e0bfee28681d194cfa13
PROBE="$WORK_DIR/gpud_probe"

PROPS=(
  vendor.debug.gpud.enable
  vendor.debug.gpud.process.name
  vendor.debug.gpud.log
  vendor.debug.gpud.force.rgb8888.enable
  vendor.debug.gpud.egl.choose.config
  vendor.debug.gpud.egl.attr.sample.buffers
  vendor.debug.gpud.egl.attr.samples
  vendor.debug.gpud.gl.shadersource.hack
  vendor.debug.gpud.fbc.disable
  vendor.debug.gpud.gl.tex.parameterf.target
  vendor.debug.gpud.gl.tex.parameterf.pname
  vendor.debug.gpud.gl.tex.parameterf.param
  vendor.debug.gpud.gl.tex.parameteri.target
  vendor.debug.gpud.gl.tex.parameteri.pname
  vendor.debug.gpud.gl.tex.parameteri.param
  vendor.debug.gpud.gl.sampler.parameterf.pname
  vendor.debug.gpud.gl.sampler.parameterf.param
  vendor.debug.gpud.gl.sampler.parameteri.pname
  vendor.debug.gpud.gl.sampler.parameteri.param
  debug.gpu.enable
  debug.gpu.force.highp
  debug.gpu.specify.app
  vendor.debug.gpud.gl.scissor.x
  vendor.debug.gpud.gl.scissor.y
  vendor.debug.gpud.gl.scissor.width
  vendor.debug.gpud.gl.scissor.height
  vendor.debug.gpud.gl.viewport.x
  vendor.debug.gpud.gl.viewport.y
  vendor.debug.gpud.gl.viewport.width
  vendor.debug.gpud.gl.viewport.height
  debug.gpu.glscissor.x
  debug.gpu.glscissor.y
  debug.gpu.glscissor.width
  debug.gpu.glscissor.height
  debug.gpu.glviewport.x
  debug.gpu.glviewport.y
  debug.gpu.glviewport.width
  debug.gpu.glviewport.height
)

say() { printf '%s\n' "$*" | tee -a "$OUT_DIR/run.log"; }
root_get() { su -c "getprop '$1'" 2>/dev/null || true; }
root_set() { su -c "setprop '$1' '$2' && [ \"\$(getprop '$1')\" = '$2' ]" >/dev/null 2>&1; }
has_key() { grep -Fxq -- "$1" "$KEYS" 2>/dev/null; }
has_keys() { local k; for k in "$@"; do has_key "$k" || return 1; done; }

RESTORE_DONE=0
restore_properties() {
  [ "$RESTORE_DONE" -eq 0 ] || return 0
  [ -s "$BACKUP" ] || return 0
  say "Memulihkan properti awal..."
  local key value failed=0
  while IFS=$'\t' read -r key value; do
    [ -n "$key" ] || continue
    root_set "$key" "$value" || failed=1
  done < "$BACKUP"
  RESTORE_DONE=1
  if [ "$failed" -eq 0 ]; then
    say "RESTORE=OK"
  else
    say "RESTORE=WARNING — periksa $BACKUP"
  fi
}
trap restore_properties EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

say "ZENKU GPUD BATCH LAB V2 — $STAMP"
say "Output: $OUT_DIR"
if ! command -v su >/dev/null 2>&1 || [ "$(su -c id -u 2>/dev/null || true)" != 0 ]; then
  say "ERROR: akses root tidak tersedia. Jalankan dari Termux dengan Magisk root."
  exit 1
fi

if ! command -v pkg >/dev/null 2>&1; then
  say "ERROR: pkg tidak ditemukan; jalankan dari Termux."
  exit 1
fi
if ! command -v clang >/dev/null 2>&1 || ! command -v strings >/dev/null 2>&1; then
  say "Memasang dependensi Termux yang diperlukan (clang + binutils)..."
  pkg install -y clang binutils
fi

if [ ! -s "$SCRIPT_DIR/gpud_probe.c" ]; then
  say "ERROR: gpud_probe.c tidak ditemukan di folder yang sama dengan script."
  exit 1
fi
say "Compile probe C (sekali, bukan APK)..."
if ! clang -std=c11 -O2 -Wall -Wextra "$SCRIPT_DIR/gpud_probe.c" -ldl -o "$PROBE" >>"$OUT_DIR/compile.log" 2>&1; then
  say "ERROR: compile gagal. Lihat $OUT_DIR/compile.log"
  exit 1
fi

sdk="$(root_get ro.build.version.sdk)"
platform="$(root_get ro.vendor.mediatek.platform)"
gpud_sha="$(su -c "sha256sum '$GPUD_LIB'" 2>/dev/null | awk '{print $1}' || true)"
mali_sha="$(su -c "sha256sum '$MALI_LIB'" 2>/dev/null | awk '{print $1}' || true)"
say "SDK=$sdk"
say "PLATFORM=$platform"
say "GPUD_SHA=${gpud_sha:-MISSING}"
say "MALI_SHA=${mali_sha:-MISSING}"

# Collect property names and preserve which vendor binary contains each string.
: > "$KEYS"
: > "$SOURCES"
for lib in "$GPUD_LIB" "$MALI_LIB"; do
  [ -e "$lib" ] || continue
  scan_file="$lib"
  if [ ! -r "$scan_file" ]; then
    scan_file="$WORK_DIR/$(basename "$lib").scan"
    su -c "cat '$lib'" > "$scan_file" 2>/dev/null || { rm -f "$scan_file"; continue; }
  fi
  found="$WORK_DIR/$(basename "$lib").properties"
  strings -a "$scan_file" 2>/dev/null \
    | grep -Eo '(vendor\.)?debug\.gpu(d)?\.[A-Za-z0-9_.-]+' | sort -u > "$found" || true
  while IFS= read -r key; do
    [ -n "$key" ] || continue
    printf '%s\n' "$key" >> "$KEYS"
    printf '%s\t%s\n' "$key" "$lib" >> "$SOURCES"
  done < "$found"
done
sort -u "$KEYS" -o "$KEYS"
sort -u "$SOURCES" -o "$SOURCES"
if [ -s "$KEYS" ]; then
  say "Property strings ditemukan: $(wc -l < "$KEYS" | tr -d ' ')"
else
  say "WARNING: tidak ada property debug.gpu* yang terdeteksi dari strings."
fi

# Snapshot every property that this run may touch before any mutation.
: > "$BACKUP"
for key in "${PROPS[@]}"; do
  value="$(root_get "$key")"
  printf '%s\t%s\n' "$key" "$value" >> "$BACKUP"
done

# Baseline is deliberately neutral and scoped to this temporary process name.
set_neutral() {
  local pair
  for pair in \
    'vendor.debug.gpud.enable|0' \
    'vendor.debug.gpud.process.name|gpulab' \
    'vendor.debug.gpud.log|0' \
    'vendor.debug.gpud.force.rgb8888.enable|0' \
    'vendor.debug.gpud.egl.choose.config|0' \
    'vendor.debug.gpud.egl.attr.sample.buffers|' \
    'vendor.debug.gpud.egl.attr.samples|' \
    'vendor.debug.gpud.gl.shadersource.hack|0' \
    'vendor.debug.gpud.fbc.disable|0' \
    'vendor.debug.gpud.gl.tex.parameterf.target|GL_TEXTURE_2D' \
    'vendor.debug.gpud.gl.tex.parameterf.pname|GL_TEXTURE_MAX_ANISOTROPY_EXT' \
    'vendor.debug.gpud.gl.tex.parameterf.param|1.0' \
    'vendor.debug.gpud.gl.tex.parameteri.target|GL_TEXTURE_2D' \
    'vendor.debug.gpud.gl.tex.parameteri.pname|GL_TEXTURE_MIN_FILTER' \
    'vendor.debug.gpud.gl.tex.parameteri.param|GL_NEAREST_MIPMAP_NEAREST' \
    'vendor.debug.gpud.gl.sampler.parameterf.pname|GL_TEXTURE_MAX_ANISOTROPY_EXT' \
    'vendor.debug.gpud.gl.sampler.parameterf.param|1.0' \
    'vendor.debug.gpud.gl.sampler.parameteri.pname|GL_TEXTURE_MIN_FILTER' \
    'vendor.debug.gpud.gl.sampler.parameteri.param|GL_NEAREST_MIPMAP_NEAREST' \
    'debug.gpu.enable|0' \
    'debug.gpu.force.highp|0' \
    'debug.gpu.specify.app|gpulab' \
    'vendor.debug.gpud.gl.scissor.x|' \
    'vendor.debug.gpud.gl.scissor.y|' \
    'vendor.debug.gpud.gl.scissor.width|' \
    'vendor.debug.gpud.gl.scissor.height|' \
    'vendor.debug.gpud.gl.viewport.x|' \
    'vendor.debug.gpud.gl.viewport.y|' \
    'vendor.debug.gpud.gl.viewport.width|' \
    'vendor.debug.gpud.gl.viewport.height|' \
    'debug.gpu.glscissor.x|' \
    'debug.gpu.glscissor.y|' \
    'debug.gpu.glscissor.width|' \
    'debug.gpu.glscissor.height|' \
    'debug.gpu.glviewport.x|' \
    'debug.gpu.glviewport.y|' \
    'debug.gpu.glviewport.width|' \
    'debug.gpu.glviewport.height|'; do
    local key="${pair%%|*}" value="${pair#*|}"
    if has_key "$key"; then
      root_set "$key" "$value" || {
        say "ERROR: gagal menerapkan nilai netral untuk $key; batch dihentikan."
        return 1
      }
    fi
  done
}

run_probe() {
  local name="$1"; shift
  local log="$OUT_DIR/${name}.log"
  say "Run: $name $*"
  if "$BASH" -c 'exec -a gpulab "$@"' _ "$PROBE" "$@" >"$log" 2>&1; then
    say "  RESULT=PROCESS_OK"
  else
    local rc=$?
    say "  RESULT=PROCESS_ERROR_$rc"
  fi
}
field() {
  local file="$1" key="$2"
  [ -f "$file" ] || return 0
  sed -n "s/^RESULT|${key}=//p" "$file" | tail -n 1
}

# Probe coordinate override hooks with sentinel values different from the
# OpenGL calls in gpud_probe.c. Effective GL state must match all four values.
run_coordinate_test() {
  local kind="$1" family="$2" prefix="$3" scenario="$4"
  local x y w h enable_key
  if [ "$kind" = scissor ]; then x=31; y=37; w=149; h=151
  else x=23; y=29; w=157; h=163; fi

  set_neutral || return 1
  for suffix in x y width height; do
    case "$suffix" in
      x) value="$x" ;; y) value="$y" ;;
      width) value="$w" ;; height) value="$h" ;;
    esac
    key="${prefix}.${suffix}"
    if ! has_key "$key"; then
      say "$scenario=SKIPPED missing_string:$key"
      set_neutral || true
      return 0
    fi
    if ! root_set "$key" "$value"; then
      say "$scenario=SKIPPED property_write_or_readback_failed:$key"
      set_neutral || true
      return 0
    fi
  done

  if [ "$family" = vendor ]; then
    enable_key=vendor.debug.gpud.enable
    if ! has_keys vendor.debug.gpud.process.name vendor.debug.gpud.enable; then
      say "$scenario=SKIPPED vendor_filter_controls_missing"
      set_neutral || true
      return 0
    fi
  else
    enable_key=debug.gpu.enable
    if ! has_keys debug.gpu.specify.app debug.gpu.enable; then
      say "$scenario=SKIPPED generic_filter_controls_missing"
      set_neutral || true
      return 0
    fi
  fi

  if ! root_set "$enable_key" 1; then
    say "$scenario=SKIPPED enable_write_or_readback_failed"
    set_neutral || true
    return 0
  fi
  run_probe "$scenario"
  set_neutral || return 1
}

# Check the exact known ROM/driver fingerprint before mutating anything.
fingerprint_base=1
[ "$sdk" = 33 ] || fingerprint_base=0
case "$platform" in MT6789|mt6789) ;; *) fingerprint_base=0 ;; esac
[ "$gpud_sha" = "$EXPECTED_GPUD_SHA" ] || fingerprint_base=0
[ "$mali_sha" = "$EXPECTED_MALI_SHA" ] || fingerprint_base=0

base_gpud_map="UNKNOWN"
base_mali_map="UNKNOWN"
if [ "$fingerprint_base" -eq 1 ] && has_keys vendor.debug.gpud.enable vendor.debug.gpud.process.name; then
  # First run a clean baseline scoped to gpulab; the game package is not targeted.
  set_neutral
  run_probe 01-baseline
  BASE_LOG="$OUT_DIR/01-baseline.log"
  base_gpud_map="$(field "$BASE_LOG" MAPPED_GPUD)"
  base_mali_map="$(field "$BASE_LOG" MAPPED_MALI)"
  run_probe 01b-lowcolor-baseline --lowcolor

  # Some vendor builds map libgpud only after enable=1. Run a neutral preflight
  # (all feature overrides remain neutral) before deciding whether to batch-test.
  set_neutral
  root_set vendor.debug.gpud.enable 1
  run_probe 01c-gpud-preflight
  preflight_gpud_map="$(field "$OUT_DIR/01c-gpud-preflight.log" MAPPED_GPUD)"
  preflight_mali_map="$(field "$OUT_DIR/01c-gpud-preflight.log" MAPPED_MALI)"
  if [ "$preflight_gpud_map" = 1 ] && [ "$preflight_mali_map" = 1 ]; then
    fingerprint_ok=1
    say "DRIVER_FINGERPRINT=KNOWN_MATCH_AND_MAPPED"
  else
    fingerprint_ok=0
    say "MUTATION_TESTS=SKIPPED — libgpud/Mali tidak keduanya terpetakan pada proses penguji."
  fi
else
  fingerprint_ok=0
  # Read-only baseline: do not touch properties on an unknown build or when
  # the binary does not advertise the two controls needed to isolate gpulab.
  run_probe 01-baseline-readonly
  BASE_LOG="$OUT_DIR/01-baseline-readonly.log"
  base_gpud_map="$(field "$BASE_LOG" MAPPED_GPUD)"
  base_mali_map="$(field "$BASE_LOG" MAPPED_MALI)"
  say "MUTATION_TESTS=SKIPPED — fingerprint or safe process-filter controls unavailable."
fi
say "BASELINE_GPUD_MAPPED=${base_gpud_map:-UNKNOWN}"
say "BASELINE_MALI_MAPPED=${base_mali_map:-UNKNOWN}"

if [ "$fingerprint_ok" -ne 1 ]; then
  say "Tidak ada properti hack yang dipaksa aktif. Hasil baseline + property strings tetap tersimpan."
else
  # Texture filtering: query back the effective GL state, for both texture and sampler APIs.
  if has_keys vendor.debug.gpud.enable vendor.debug.gpud.process.name \
      vendor.debug.gpud.gl.tex.parameterf.target vendor.debug.gpud.gl.tex.parameterf.pname vendor.debug.gpud.gl.tex.parameterf.param \
      vendor.debug.gpud.gl.tex.parameteri.target vendor.debug.gpud.gl.tex.parameteri.pname vendor.debug.gpud.gl.tex.parameteri.param; then
    set_neutral
    root_set vendor.debug.gpud.gl.tex.parameterf.param 4.0
    root_set vendor.debug.gpud.gl.tex.parameteri.param GL_LINEAR_MIPMAP_LINEAR
    if has_keys vendor.debug.gpud.gl.sampler.parameterf.pname vendor.debug.gpud.gl.sampler.parameterf.param \
        vendor.debug.gpud.gl.sampler.parameteri.pname vendor.debug.gpud.gl.sampler.parameteri.param; then
      root_set vendor.debug.gpud.gl.sampler.parameterf.param 4.0
      root_set vendor.debug.gpud.gl.sampler.parameteri.param GL_LINEAR_MIPMAP_LINEAR
    fi
    root_set vendor.debug.gpud.enable 1
    run_probe 02-af4-trilinear
    af_max="$(field "$BASE_LOG" AF_MAX)"
    if awk -v v="${af_max:-0}" 'BEGIN{exit !(v>=15.9)}'; then
      set_neutral
      root_set vendor.debug.gpud.gl.tex.parameterf.param 16.0
      root_set vendor.debug.gpud.gl.tex.parameteri.param GL_LINEAR_MIPMAP_LINEAR
      if has_keys vendor.debug.gpud.gl.sampler.parameterf.pname vendor.debug.gpud.gl.sampler.parameterf.param \
          vendor.debug.gpud.gl.sampler.parameteri.pname vendor.debug.gpud.gl.sampler.parameteri.param; then
        root_set vendor.debug.gpud.gl.sampler.parameterf.param 16.0
        root_set vendor.debug.gpud.gl.sampler.parameteri.param GL_LINEAR_MIPMAP_LINEAR
      fi
      root_set vendor.debug.gpud.enable 1
      run_probe 03-af16-trilinear
    else
      say "AF16=SKIPPED (driver-reported max AF < 16x or unavailable)"
    fi
  else
    say "AF_TRILINEAR=SKIPPED (required property strings not found)"
  fi

  if has_keys vendor.debug.gpud.enable vendor.debug.gpud.process.name vendor.debug.gpud.force.rgb8888.enable; then
    set_neutral
    root_set vendor.debug.gpud.force.rgb8888.enable 1
    root_set vendor.debug.gpud.enable 1
    run_probe 04a-rgba-force-only --lowcolor
    # Some GPUD builds apply EGL attribute rewriting only when the chooser hook
    # is enabled. Test that combination independently instead of assuming it.
    set_neutral
    root_set vendor.debug.gpud.force.rgb8888.enable 1
    if has_keys vendor.debug.gpud.egl.choose.config; then
      root_set vendor.debug.gpud.egl.attr.sample.buffers 0
      root_set vendor.debug.gpud.egl.attr.samples 0
      root_set vendor.debug.gpud.egl.choose.config 1
      root_set vendor.debug.gpud.enable 1
      run_probe 04b-rgba-force-plus-egl --lowcolor
    else
      say "RGBA_FORCE_PLUS_EGL=SKIPPED (egl.choose.config string not found)"
    fi
  else
    say "RGBA8888=SKIPPED (property strings not found)"
  fi

  if has_keys vendor.debug.gpud.enable vendor.debug.gpud.process.name \
      vendor.debug.gpud.egl.choose.config vendor.debug.gpud.egl.attr.sample.buffers vendor.debug.gpud.egl.attr.samples; then
    set_neutral
    root_set vendor.debug.gpud.egl.attr.sample.buffers 1
    root_set vendor.debug.gpud.egl.attr.samples 4
    root_set vendor.debug.gpud.egl.choose.config 1
    root_set vendor.debug.gpud.enable 1
    run_probe 05-native-msaa4
  else
    say "MSAA4=SKIPPED (required property strings not found)"
  fi

  # Scissor and viewport hooks: test vendor GPUD and generic debug.gpu
  # namespaces separately. Property names and values are exact candidates
  # discovered in this ROM's driver binaries; no candidate is guessed.
  if has_keys vendor.debug.gpud.enable vendor.debug.gpud.process.name; then
    run_coordinate_test scissor vendor vendor.debug.gpud.gl.scissor 09-vendor-scissor
    run_coordinate_test viewport vendor vendor.debug.gpud.gl.viewport 10-vendor-viewport
  else
    say "VENDOR_SCISSOR_VIEWPORT=SKIPPED (vendor controls missing)"
  fi
  if has_keys debug.gpu.enable debug.gpu.specify.app; then
    run_coordinate_test scissor debug debug.gpu.glscissor 11-debug-scissor
    run_coordinate_test viewport debug debug.gpu.glviewport 12-debug-viewport
  else
    say "DEBUG_SCISSOR_VIEWPORT=SKIPPED (generic controls missing)"
  fi

  if has_keys vendor.debug.gpud.enable vendor.debug.gpud.process.name vendor.debug.gpud.gl.shadersource.hack; then
    set_neutral
    root_set vendor.debug.gpud.gl.shadersource.hack 1
    root_set vendor.debug.gpud.enable 1
    run_probe 06-shader-source-hack
  else
    say "SHADER_SOURCE=SKIPPED (property string not found)"
  fi

  if has_keys vendor.debug.gpud.enable vendor.debug.gpud.process.name vendor.debug.gpud.fbc.disable; then
    set_neutral
    root_set vendor.debug.gpud.fbc.disable 1
    root_set vendor.debug.gpud.enable 1
    run_probe 07-fbc-disable
    say "FBC_EFFECT=INCONCLUSIVE (Pbuffer readback cannot prove framebuffer compression state)"
  else
    say "FBC_DISABLE=SKIPPED (property string not found)"
  fi

  if has_keys debug.gpu.enable debug.gpu.force.highp debug.gpu.specify.app; then
    set_neutral
    root_set debug.gpu.specify.app gpulab
    root_set debug.gpu.force.highp 1
    root_set debug.gpu.enable 1
    run_probe 08-highp
    say "HIGHP_EFFECT=INCONCLUSIVE (precision capability query is not proof that the property was consumed)"
  else
    say "HIGHP=SKIPPED (one or more exact strings not found in Mali/GPUD binaries)"
  fi
fi

# Derive conservative observations from read-backs. These are deliberately not
# called PASS unless an actual API state/config value changes as requested.
num_ge() { awk -v x="${1:-0}" -v y="$2" 'BEGIN { exit !((x+0) >= (y+0)) }'; }
AF4_STATUS=NOT_RUN
AF16_STATUS=NOT_RUN
TRILINEAR_STATUS=NOT_RUN
RGBA_FORCE_ONLY_STATUS=NOT_RUN
RGBA_FORCE_EGL_STATUS=NOT_RUN
MSAA_STATUS=NOT_RUN
SCISSOR_VENDOR_STATUS=NOT_RUN
VIEWPORT_VENDOR_STATUS=NOT_RUN
SCISSOR_DEBUG_STATUS=NOT_RUN
VIEWPORT_DEBUG_STATUS=NOT_RUN
SHADER_STATUS=INCONCLUSIVE
FBC_STATUS=INCONCLUSIVE
HIGHP_STATUS=INCONCLUSIVE
if [ -f "$OUT_DIR/02-af4-trilinear.log" ]; then
  af4_value="$(field "$OUT_DIR/02-af4-trilinear.log" TEX_AF)"
  if num_ge "$af4_value" 3.9; then AF4_STATUS=OVERRIDE_READBACK_OBSERVED; else AF4_STATUS=NO_OVERRIDE_READBACK; fi
  if [ "$(field "$OUT_DIR/02-af4-trilinear.log" TEX_MIN_FILTER)" = 0x2703 ]; then
    TRILINEAR_STATUS=OVERRIDE_READBACK_OBSERVED
  else
    TRILINEAR_STATUS=NO_OVERRIDE_READBACK
  fi
fi
if [ -f "$OUT_DIR/03-af16-trilinear.log" ]; then
  if num_ge "$(field "$OUT_DIR/03-af16-trilinear.log" TEX_AF)" 15.9; then
    AF16_STATUS=OVERRIDE_READBACK_OBSERVED
  else
    AF16_STATUS=NO_OVERRIDE_READBACK
  fi
fi
rgba_status_for_log() {
  local file="$1" bfile="$2"
  local rb gb bb ab br bg bb0 ba
  [ -f "$file" ] || { echo NOT_RUN; return; }
  rb="$(field "$file" CONFIG_RED)"; gb="$(field "$file" CONFIG_GREEN)"
  bb="$(field "$file" CONFIG_BLUE)"; ab="$(field "$file" CONFIG_ALPHA)"
  br="$(field "$bfile" CONFIG_RED)"; bg="$(field "$bfile" CONFIG_GREEN)"
  bb0="$(field "$bfile" CONFIG_BLUE)"; ba="$(field "$bfile" CONFIG_ALPHA)"
  if num_ge "$rb" 8 && num_ge "$gb" 8 && num_ge "$bb" 8 && num_ge "$ab" 8; then
    if num_ge "$br" 8 && num_ge "$bg" 8 && num_ge "$bb0" 8 && num_ge "$ba" 8; then
      echo BASELINE_ALREADY_8888
    else
      echo FORCE_8888_READBACK_OBSERVED
    fi
  else
    echo 8888_NOT_OBSERVED
  fi
}
RGBA_FORCE_ONLY_STATUS="$(rgba_status_for_log "$OUT_DIR/04a-rgba-force-only.log" "$OUT_DIR/01b-lowcolor-baseline.log")"
RGBA_FORCE_EGL_STATUS="$(rgba_status_for_log "$OUT_DIR/04b-rgba-force-plus-egl.log" "$OUT_DIR/01b-lowcolor-baseline.log")"

coordinate_status() {
  local file="$1" kind="$2"
  local actual expected
  [ -f "$file" ] || { echo NOT_RUN; return; }
  actual="$(field "$file" "$kind")"
  if [ "$kind" = SCISSOR ]; then expected='31,37,149,151'
  else expected='23,29,157,163'; fi
  if [ "$actual" = "$expected" ]; then echo OVERRIDE_READBACK_OBSERVED
  else echo NO_OVERRIDE_READBACK; fi
}
SCISSOR_VENDOR_STATUS="$(coordinate_status "$OUT_DIR/09-vendor-scissor.log" SCISSOR)"
VIEWPORT_VENDOR_STATUS="$(coordinate_status "$OUT_DIR/10-vendor-viewport.log" VIEWPORT)"
SCISSOR_DEBUG_STATUS="$(coordinate_status "$OUT_DIR/11-debug-scissor.log" SCISSOR)"
VIEWPORT_DEBUG_STATUS="$(coordinate_status "$OUT_DIR/12-debug-viewport.log" VIEWPORT)"
if [ -f "$OUT_DIR/05-native-msaa4.log" ]; then
  sb="$(field "$OUT_DIR/05-native-msaa4.log" CONFIG_SAMPLE_BUFFERS)"
  sm="$(field "$OUT_DIR/05-native-msaa4.log" CONFIG_SAMPLES)"
  if num_ge "$sb" 1 && num_ge "$sm" 4; then
    bsb="$(field "$BASE_LOG" CONFIG_SAMPLE_BUFFERS)"
    bsm="$(field "$BASE_LOG" CONFIG_SAMPLES)"
    if num_ge "$bsb" 1 && num_ge "$bsm" 4; then
      MSAA_STATUS=BASELINE_ALREADY_MSAA4
    else
      MSAA_STATUS=MSAA4_READBACK_OBSERVED
    fi
  else
    MSAA_STATUS=MSAA4_NOT_OBSERVED
  fi
fi
if [ -f "$OUT_DIR/06-shader-source-hack.log" ]; then
  if [ "$(field "$OUT_DIR/06-shader-source-hack.log" SHADER_COMPILE)" = 1 ] && \
     [ "$(field "$OUT_DIR/06-shader-source-hack.log" SHADER_SOURCE_CHANGED)" = 1 ]; then
    SHADER_STATUS=SOURCE_CHANGE_VISIBLE
  else
    SHADER_STATUS=INCONCLUSIVE_NO_SOURCE_CHANGE_PROVEN
  fi
fi
if [ -f "$OUT_DIR/07-fbc-disable.log" ]; then FBC_STATUS=INCONCLUSIVE_NO_FBC_COUNTER; fi
if [ -f "$OUT_DIR/08-highp.log" ]; then HIGHP_STATUS=INCONCLUSIVE_PRECISION_QUERY_ONLY; fi

# Report string-discovered scissor/viewport candidates without guessing their values.
scissor_keys="$(grep -i 'scissor' "$KEYS" || true)"
viewport_keys="$(grep -i 'viewport' "$KEYS" || true)"
{
  echo "ZENKU GPUD BATCH LAB V2 — $STAMP"
  echo "Device: SDK=$sdk platform=$platform"
  echo "GPUD SHA: ${gpud_sha:-MISSING}"
  echo "Mali SHA: ${mali_sha:-MISSING}"
  echo "Expected GPUD SHA: $EXPECTED_GPUD_SHA"
  echo "Expected Mali SHA: $EXPECTED_MALI_SHA"
  echo "Baseline mapped: GPUD=${base_gpud_map:-UNKNOWN} Mali=${base_mali_map:-UNKNOWN}"
  echo
  echo "[BASELINE]"
  for key in GL_VENDOR GL_RENDERER GL_VERSION CONFIG_RED CONFIG_GREEN CONFIG_BLUE CONFIG_ALPHA CONFIG_BUFFER CONFIG_SAMPLE_BUFFERS CONFIG_SAMPLES GL_SAMPLES AF_MAX TEX_AF TEX_MIN_FILTER SAMPLER_AF SAMPLER_MIN_FILTER VIEWPORT SCISSOR MEDIUMP_PRECISION HIGHP_PRECISION; do
    printf '%s=%s\n' "$key" "$(field "$BASE_LOG" "$key")"
  done
  echo
  for scenario in 01b-lowcolor-baseline 01c-gpud-preflight 02-af4-trilinear 03-af16-trilinear 04a-rgba-force-only 04b-rgba-force-plus-egl 05-native-msaa4 09-vendor-scissor 10-vendor-viewport 11-debug-scissor 12-debug-viewport 06-shader-source-hack 07-fbc-disable 08-highp; do
    file="$OUT_DIR/${scenario}.log"
    [ -f "$file" ] || continue
    echo "[$scenario]"
    for key in MAPPED_GPUD MAPPED_MALI GL_RENDERER CONFIG_RED CONFIG_GREEN CONFIG_BLUE CONFIG_ALPHA CONFIG_BUFFER CONFIG_SAMPLE_BUFFERS CONFIG_SAMPLES GL_SAMPLES AF_MAX TEX_AF TEX_MIN_FILTER SAMPLER_AF SAMPLER_MIN_FILTER SHADER_COMPILE SHADER_SOURCE_CHANGED MEDIUMP_PRECISION HIGHP_PRECISION VIEWPORT SCISSOR GL_ERROR; do
      value="$(field "$file" "$key")"
      [ -n "$value" ] && printf '%s=%s\n' "$key" "$value"
    done
    echo
  done
  echo "[INTERPRETED_READBACKS]"
  echo "AF4=$AF4_STATUS"
  echo "AF16=$AF16_STATUS"
  echo "TRILINEAR=$TRILINEAR_STATUS"
  echo "RGBA_FORCE_ONLY=$RGBA_FORCE_ONLY_STATUS"
  echo "RGBA_FORCE_PLUS_EGL=$RGBA_FORCE_EGL_STATUS"
  echo "MSAA4=$MSAA_STATUS"
  echo "SCISSOR_VENDOR=$SCISSOR_VENDOR_STATUS"
  echo "VIEWPORT_VENDOR=$VIEWPORT_VENDOR_STATUS"
  echo "SCISSOR_DEBUG=$SCISSOR_DEBUG_STATUS"
  echo "VIEWPORT_DEBUG=$VIEWPORT_DEBUG_STATUS"
  echo "SHADER_SOURCE=$SHADER_STATUS"
  echo "FBC=$FBC_STATUS"
  echo "HIGHP=$HIGHP_STATUS"
  echo
  echo "[PROPERTY_STRING_SOURCES]"
  cat "$SOURCES"
  echo
  echo "[SCISSOR_PROPERTY_STRINGS]"
  if [ -n "$scissor_keys" ]; then printf '%s\n' "$scissor_keys"; else echo NONE_FOUND; fi
  echo
  echo "[VIEWPORT_PROPERTY_STRINGS]"
  if [ -n "$viewport_keys" ]; then printf '%s\n' "$viewport_keys"; else echo NONE_FOUND; fi
  echo
  echo "Interpretation rules:"
  echo "- A property being writable/readable is not proof that the driver consumes it."
  echo "- AF/trilinear are checked through GL state readback; EGL/MSAA and RGBA through the selected EGLConfig."
  echo "- FBC and forced-precision effects remain INCONCLUSIVE without a driver-level counter/log or output behavior test."
  echo "- Scissor/viewport are tested with separate property namespaces and distinct in-range sentinels; only matching GL state readback is reported as observed."
  echo "- Full raw logs are in this directory."
} > "$REPORT"

restore_properties
say "Selesai. Ringkasan: $REPORT"
say "Raw logs: $OUT_DIR"
