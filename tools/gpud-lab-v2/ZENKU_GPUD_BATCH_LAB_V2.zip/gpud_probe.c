#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* Minimal EGL/GLES declarations: link only to libdl, load Android's system
 * EGL/GLES libraries by absolute path, and avoid Termux's Mesa packages. */
typedef void *EGLDisplay;
typedef void *EGLConfig;
typedef void *EGLSurface;
typedef void *EGLContext;
typedef unsigned int EGLBoolean;
typedef unsigned int EGLenum;
typedef int EGLint;
typedef unsigned int GLenum;
typedef unsigned int GLuint;
typedef int GLint;
typedef int GLsizei;
typedef float GLfloat;
typedef char GLchar;
typedef unsigned char GLubyte;
typedef unsigned char GLboolean;

#define EGL_FALSE 0
#define EGL_DEFAULT_DISPLAY ((void *)0)
#define EGL_NONE 0x3038
#define EGL_SURFACE_TYPE 0x3033
#define EGL_PBUFFER_BIT 0x0001
#define EGL_RENDERABLE_TYPE 0x3040
#define EGL_OPENGL_ES3_BIT 0x0040
#define EGL_RED_SIZE 0x3024
#define EGL_GREEN_SIZE 0x3023
#define EGL_BLUE_SIZE 0x3022
#define EGL_ALPHA_SIZE 0x3021
#define EGL_BUFFER_SIZE 0x3020
#define EGL_SAMPLE_BUFFERS 0x3032
#define EGL_SAMPLES 0x3031
#define EGL_WIDTH 0x3057
#define EGL_HEIGHT 0x3056
#define EGL_CONTEXT_CLIENT_VERSION 0x3098
#define EGL_OPENGL_ES_API 0x30A0
#define EGL_VENDOR 0x3053
#define EGL_VERSION 0x3054
#define EGL_EXTENSIONS 0x3055

#define GL_VENDOR 0x1F00
#define GL_RENDERER 0x1F01
#define GL_VERSION 0x1F02
#define GL_EXTENSIONS 0x1F03
#define GL_TEXTURE_2D 0x0DE1
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_NEAREST 0x2600
#define GL_NEAREST_MIPMAP_NEAREST 0x2700
#define GL_LINEAR_MIPMAP_LINEAR 0x2703
#define GL_TEXTURE_MAX_ANISOTROPY_EXT 0x84FE
#define GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT 0x84FF
#define GL_SCISSOR_BOX 0x0C10
#define GL_VIEWPORT 0x0BA2
#define GL_SAMPLES 0x80A9
#define GL_MAX_SAMPLES 0x8D57
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPILE_STATUS 0x8B81
#define GL_INFO_LOG_LENGTH 0x8B84
#define GL_MEDIUM_FLOAT 0x8DF1
#define GL_HIGH_FLOAT 0x8DF2

static void *g_egl;
static void *g_gles;

typedef EGLDisplay (*PFN_eglGetDisplay)(void *);
typedef EGLBoolean (*PFN_eglInitialize)(EGLDisplay, EGLint *, EGLint *);
typedef EGLBoolean (*PFN_eglBindAPI)(EGLenum);
typedef EGLBoolean (*PFN_eglChooseConfig)(EGLDisplay, const EGLint *, EGLConfig *, EGLint, EGLint *);
typedef EGLSurface (*PFN_eglCreatePbufferSurface)(EGLDisplay, EGLConfig, const EGLint *);
typedef EGLContext (*PFN_eglCreateContext)(EGLDisplay, EGLConfig, EGLContext, const EGLint *);
typedef EGLBoolean (*PFN_eglMakeCurrent)(EGLDisplay, EGLSurface, EGLSurface, EGLContext);
typedef EGLBoolean (*PFN_eglGetConfigAttrib)(EGLDisplay, EGLConfig, EGLint, EGLint *);
typedef EGLint (*PFN_eglGetError)(void);
typedef const char *(*PFN_eglQueryString)(EGLDisplay, EGLint);
typedef void *(*PFN_eglGetProcAddress)(const char *);

static PFN_eglGetProcAddress p_eglGetProcAddress;
#define LOAD_EGL(var, name) do { *(void **)(&(var)) = dlsym(g_egl, name); if (!(var)) { fprintf(stderr, "Missing EGL symbol: %s\n", name); return 20; } } while (0)
#define LOAD_GL(var, name) do { void *sym_ = dlsym(g_gles, name); if (!sym_ && p_eglGetProcAddress) sym_ = p_eglGetProcAddress(name); *(void **)(&(var)) = sym_; } while (0)

static int contains(const char *haystack, const char *needle) {
    return haystack && needle && strstr(haystack, needle) != NULL;
}

static void report_maps(void) {
    FILE *fp = fopen("/proc/self/maps", "r");
    char line[1024];
    int gpud = 0, mali = 0, egl = 0;
    if (fp) {
        while (fgets(line, sizeof(line), fp)) {
            if (contains(line, "libgpud.so")) gpud = 1;
            if (contains(line, "libGLES_mali.so")) mali = 1;
            if (contains(line, "libEGL.so")) egl = 1;
            if (contains(line, "libgpud.so") || contains(line, "libGLES_mali.so"))
                printf("MAP|%s", line);
        }
        fclose(fp);
    }
    printf("RESULT|MAPPED_GPUD=%d\n", gpud);
    printf("RESULT|MAPPED_MALI=%d\n", mali);
    printf("RESULT|MAPPED_EGL=%d\n", egl);
}

static void report_proc_name(void) {
    char buf[256] = {0};
    FILE *fp = fopen("/proc/self/cmdline", "rb");
    if (fp) {
        size_t n = fread(buf, 1, sizeof(buf) - 1, fp);
        fclose(fp);
        for (size_t i = 0; i < n; i++) if (buf[i] == '\0') buf[i] = ' ';
    }
    printf("RESULT|CMDLINE=%s\n", buf[0] ? buf : "UNKNOWN");
}

int main(int argc, char **argv) {
    int low_color = 0;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--lowcolor") == 0) low_color = 1;
        else if (strcmp(argv[i], "--help") == 0) {
            puts("Usage: gpud_probe [--lowcolor]");
            return 0;
        }
    }

    g_egl = dlopen("/system/lib64/libEGL.so", RTLD_NOW | RTLD_LOCAL);
    if (!g_egl) {
        printf("FATAL|dlopen_EGL=%s\n", dlerror());
        return 10;
    }
    g_gles = dlopen("/system/lib64/libGLESv3.so", RTLD_NOW | RTLD_LOCAL);
    if (!g_gles) g_gles = dlopen("/system/lib64/libGLESv2.so", RTLD_NOW | RTLD_LOCAL);
    if (!g_gles) {
        printf("FATAL|dlopen_GLES=%s\n", dlerror());
        return 11;
    }

    PFN_eglGetDisplay p_eglGetDisplay = NULL;
    PFN_eglInitialize p_eglInitialize = NULL;
    PFN_eglBindAPI p_eglBindAPI = NULL;
    PFN_eglChooseConfig p_eglChooseConfig = NULL;
    PFN_eglCreatePbufferSurface p_eglCreatePbufferSurface = NULL;
    PFN_eglCreateContext p_eglCreateContext = NULL;
    PFN_eglMakeCurrent p_eglMakeCurrent = NULL;
    PFN_eglGetConfigAttrib p_eglGetConfigAttrib = NULL;
    PFN_eglGetError p_eglGetError = NULL;
    PFN_eglQueryString p_eglQueryString = NULL;
    LOAD_EGL(p_eglGetDisplay, "eglGetDisplay");
    LOAD_EGL(p_eglInitialize, "eglInitialize");
    LOAD_EGL(p_eglBindAPI, "eglBindAPI");
    LOAD_EGL(p_eglChooseConfig, "eglChooseConfig");
    LOAD_EGL(p_eglCreatePbufferSurface, "eglCreatePbufferSurface");
    LOAD_EGL(p_eglCreateContext, "eglCreateContext");
    LOAD_EGL(p_eglMakeCurrent, "eglMakeCurrent");
    LOAD_EGL(p_eglGetConfigAttrib, "eglGetConfigAttrib");
    LOAD_EGL(p_eglGetError, "eglGetError");
    LOAD_EGL(p_eglQueryString, "eglQueryString");
    *(void **)(&p_eglGetProcAddress) = dlsym(g_egl, "eglGetProcAddress");

    EGLDisplay display = p_eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (!display) {
        printf("FATAL|eglGetDisplay=0x%04x\n", p_eglGetError());
        return 12;
    }
    EGLint major = 0, minor = 0;
    if (p_eglInitialize(display, &major, &minor) == EGL_FALSE) {
        printf("FATAL|eglInitialize=0x%04x\n", p_eglGetError());
        return 13;
    }
    if (p_eglBindAPI(EGL_OPENGL_ES_API) == EGL_FALSE) {
        printf("FATAL|eglBindAPI=0x%04x\n", p_eglGetError());
        return 14;
    }

    const EGLint attrs_8888[] = {
        EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_NONE
    };
    const EGLint attrs_low[] = {
        EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_RED_SIZE, 5, EGL_GREEN_SIZE, 6,
        EGL_BLUE_SIZE, 5, EGL_ALPHA_SIZE, 0,
        EGL_NONE
    };
    const EGLint *cfg_attrs = low_color ? attrs_low : attrs_8888;
    EGLConfig configs[64] = {0};
    EGLint config_count = 0;
    if (p_eglChooseConfig(display, cfg_attrs, configs, 64, &config_count) == EGL_FALSE || config_count < 1) {
        printf("FATAL|eglChooseConfig=0x%04x|count=%d\n", p_eglGetError(), config_count);
        return 15;
    }
    EGLConfig config = configs[0];
    /* EGL channel-size attributes are minimums, not exact values. For the
     * low-colour baseline, inspect every returned config and choose the one
     * with the smallest total channel depth so a 565 path is actually tested
     * when the driver exposes one. */
    if (low_color) {
        int best_score = INT_MAX;
        for (EGLint i = 0; i < config_count; i++) {
            EGLint r = 0, g = 0, b = 0, a = 0;
            p_eglGetConfigAttrib(display, configs[i], EGL_RED_SIZE, &r);
            p_eglGetConfigAttrib(display, configs[i], EGL_GREEN_SIZE, &g);
            p_eglGetConfigAttrib(display, configs[i], EGL_BLUE_SIZE, &b);
            p_eglGetConfigAttrib(display, configs[i], EGL_ALPHA_SIZE, &a);
            int score = r + g + b + a;
            if (score < best_score) {
                best_score = score;
                config = configs[i];
            }
        }
    }
    EGLint red = -1, green = -1, blue = -1, alpha = -1;
    EGLint buffer = -1, sample_buffers = -1, samples = -1;
    p_eglGetConfigAttrib(display, config, EGL_RED_SIZE, &red);
    p_eglGetConfigAttrib(display, config, EGL_GREEN_SIZE, &green);
    p_eglGetConfigAttrib(display, config, EGL_BLUE_SIZE, &blue);
    p_eglGetConfigAttrib(display, config, EGL_ALPHA_SIZE, &alpha);
    p_eglGetConfigAttrib(display, config, EGL_BUFFER_SIZE, &buffer);
    p_eglGetConfigAttrib(display, config, EGL_SAMPLE_BUFFERS, &sample_buffers);
    p_eglGetConfigAttrib(display, config, EGL_SAMPLES, &samples);

    const EGLint pbuffer_attrs[] = { EGL_WIDTH, 256, EGL_HEIGHT, 256, EGL_NONE };
    const EGLint context_attrs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    EGLSurface surface = p_eglCreatePbufferSurface(display, config, pbuffer_attrs);
    if (!surface) {
        printf("FATAL|eglCreatePbufferSurface=0x%04x\n", p_eglGetError());
        return 16;
    }
    EGLContext context = p_eglCreateContext(display, config, NULL, context_attrs);
    if (!context) {
        printf("FATAL|eglCreateContext=0x%04x\n", p_eglGetError());
        return 17;
    }
    if (p_eglMakeCurrent(display, surface, surface, context) == EGL_FALSE) {
        printf("FATAL|eglMakeCurrent=0x%04x\n", p_eglGetError());
        return 18;
    }

    const char *egl_vendor = p_eglQueryString(display, EGL_VENDOR);
    const char *egl_version = p_eglQueryString(display, EGL_VERSION);
    const char *egl_extensions = p_eglQueryString(display, EGL_EXTENSIONS);
    printf("RESULT|EGL_VERSION=%d.%d\n", major, minor);
    printf("RESULT|EGL_VENDOR=%s\n", egl_vendor ? egl_vendor : "UNKNOWN");
    printf("RESULT|EGL_VERSION_STRING=%s\n", egl_version ? egl_version : "UNKNOWN");
    printf("RESULT|EGL_CONFIG_COUNT=%d\n", config_count);
    printf("RESULT|CONFIG_RED=%d\n", red);
    printf("RESULT|CONFIG_GREEN=%d\n", green);
    printf("RESULT|CONFIG_BLUE=%d\n", blue);
    printf("RESULT|CONFIG_ALPHA=%d\n", alpha);
    printf("RESULT|CONFIG_BUFFER=%d\n", buffer);
    printf("RESULT|CONFIG_SAMPLE_BUFFERS=%d\n", sample_buffers);
    printf("RESULT|CONFIG_SAMPLES=%d\n", samples);
    printf("RESULT|EGL_EXTENSIONS_HAS_KHR_SURFACELESS=%d\n", contains(egl_extensions, "EGL_KHR_surfaceless_context"));

    const GLubyte *(*glGetString)(GLenum) = NULL;
    void (*glGetIntegerv)(GLenum, GLint *) = NULL;
    void (*glGetFloatv)(GLenum, GLfloat *) = NULL;
    GLenum (*glGetError)(void) = NULL;
    void (*glGenTextures)(GLsizei, GLuint *) = NULL;
    void (*glBindTexture)(GLenum, GLuint) = NULL;
    void (*glTexParameteri)(GLenum, GLenum, GLint) = NULL;
    void (*glTexParameterf)(GLenum, GLenum, GLfloat) = NULL;
    void (*glGetTexParameteriv)(GLenum, GLenum, GLint *) = NULL;
    void (*glGetTexParameterfv)(GLenum, GLenum, GLfloat *) = NULL;
    void (*glViewport)(GLint, GLint, GLsizei, GLsizei) = NULL;
    void (*glScissor)(GLint, GLint, GLsizei, GLsizei) = NULL;
    GLuint (*glCreateShader)(GLenum) = NULL;
    void (*glShaderSource)(GLuint, GLsizei, const GLchar *const *, const GLint *) = NULL;
    void (*glCompileShader)(GLuint) = NULL;
    void (*glGetShaderiv)(GLuint, GLenum, GLint *) = NULL;
    void (*glGetShaderInfoLog)(GLuint, GLsizei, GLsizei *, GLchar *) = NULL;
    void (*glGetShaderSource)(GLuint, GLsizei, GLsizei *, GLchar *) = NULL;
    void (*glGetShaderPrecisionFormat)(GLenum, GLenum, GLint *, GLint *) = NULL;
    void (*glDeleteShader)(GLuint) = NULL;
    void (*glGenSamplers)(GLsizei, GLuint *) = NULL;
    void (*glSamplerParameteri)(GLuint, GLenum, GLint) = NULL;
    void (*glSamplerParameterf)(GLuint, GLenum, GLfloat) = NULL;
    void (*glGetSamplerParameteriv)(GLuint, GLenum, GLint *) = NULL;
    void (*glGetSamplerParameterfv)(GLuint, GLenum, GLfloat *) = NULL;
    LOAD_GL(glGetString, "glGetString");
    LOAD_GL(glGetIntegerv, "glGetIntegerv");
    LOAD_GL(glGetFloatv, "glGetFloatv");
    LOAD_GL(glGetError, "glGetError");
    LOAD_GL(glGenTextures, "glGenTextures");
    LOAD_GL(glBindTexture, "glBindTexture");
    LOAD_GL(glTexParameteri, "glTexParameteri");
    LOAD_GL(glTexParameterf, "glTexParameterf");
    LOAD_GL(glGetTexParameteriv, "glGetTexParameteriv");
    LOAD_GL(glGetTexParameterfv, "glGetTexParameterfv");
    LOAD_GL(glViewport, "glViewport");
    LOAD_GL(glScissor, "glScissor");
    LOAD_GL(glCreateShader, "glCreateShader");
    LOAD_GL(glShaderSource, "glShaderSource");
    LOAD_GL(glCompileShader, "glCompileShader");
    LOAD_GL(glGetShaderiv, "glGetShaderiv");
    LOAD_GL(glGetShaderInfoLog, "glGetShaderInfoLog");
    LOAD_GL(glGetShaderSource, "glGetShaderSource");
    LOAD_GL(glGetShaderPrecisionFormat, "glGetShaderPrecisionFormat");
    LOAD_GL(glDeleteShader, "glDeleteShader");
    LOAD_GL(glGenSamplers, "glGenSamplers");
    LOAD_GL(glSamplerParameteri, "glSamplerParameteri");
    LOAD_GL(glSamplerParameterf, "glSamplerParameterf");
    LOAD_GL(glGetSamplerParameteriv, "glGetSamplerParameteriv");
    LOAD_GL(glGetSamplerParameterfv, "glGetSamplerParameterfv");

    if (!glGetString || !glGetIntegerv || !glGetFloatv || !glGetError ||
        !glGenTextures || !glBindTexture || !glTexParameteri || !glTexParameterf ||
        !glGetTexParameteriv || !glGetTexParameterfv || !glViewport || !glScissor ||
        !glCreateShader || !glShaderSource || !glCompileShader || !glGetShaderiv ||
        !glGetShaderInfoLog || !glGetShaderSource || !glGetShaderPrecisionFormat ||
        !glDeleteShader) {
        fprintf(stderr, "Missing required GLES entry point; cannot run a valid probe.\n");
        return 21;
    }

    const char *gl_vendor = (const char *)glGetString(GL_VENDOR);
    const char *gl_renderer = (const char *)glGetString(GL_RENDERER);
    const char *gl_version = (const char *)glGetString(GL_VERSION);
    const char *gl_extensions = (const char *)glGetString(GL_EXTENSIONS);
    printf("RESULT|GL_VENDOR=%s\n", gl_vendor ? gl_vendor : "UNKNOWN");
    printf("RESULT|GL_RENDERER=%s\n", gl_renderer ? gl_renderer : "UNKNOWN");
    printf("RESULT|GL_VERSION=%s\n", gl_version ? gl_version : "UNKNOWN");
    printf("RESULT|GL_EXTENSIONS_HAS_ANISO=%d\n", contains(gl_extensions, "GL_EXT_texture_filter_anisotropic"));
    GLint gl_samples = -1, max_samples = -1;
    glGetIntegerv(GL_SAMPLES, &gl_samples);
    glGetIntegerv(GL_MAX_SAMPLES, &max_samples);
    printf("RESULT|GL_SAMPLES=%d\n", gl_samples);
    printf("RESULT|GL_MAX_SAMPLES=%d\n", max_samples);

    report_proc_name();
    report_maps();

    GLuint texture = 0;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    GLint min_filter = -1, mag_filter = -1;
    glGetTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, &min_filter);
    glGetTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, &mag_filter);
    printf("RESULT|TEX_MIN_FILTER=0x%04x\n", min_filter);
    printf("RESULT|TEX_MAG_FILTER=0x%04x\n", mag_filter);
    if (contains(gl_extensions, "GL_EXT_texture_filter_anisotropic")) {
        GLfloat max_aniso = 0.0f, tex_aniso = 0.0f;
        glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &max_aniso);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0f);
        glGetTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, &tex_aniso);
        printf("RESULT|AF_MAX=%.3f\n", max_aniso);
        printf("RESULT|TEX_AF=%.3f\n", tex_aniso);
    } else {
        printf("RESULT|AF_MAX=0\nRESULT|TEX_AF=0\n");
    }

    GLuint sampler = 0;
    if (glGenSamplers && glSamplerParameteri && glSamplerParameterf &&
        glGetSamplerParameteriv && glGetSamplerParameterfv) {
        glGenSamplers(1, &sampler);
    }
    if (sampler) {
        glSamplerParameteri(sampler, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
        glSamplerParameteri(sampler, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        GLint sampler_min = -1, sampler_mag = -1;
        glGetSamplerParameteriv(sampler, GL_TEXTURE_MIN_FILTER, &sampler_min);
        glGetSamplerParameteriv(sampler, GL_TEXTURE_MAG_FILTER, &sampler_mag);
        printf("RESULT|SAMPLER_MIN_FILTER=0x%04x\n", sampler_min);
        printf("RESULT|SAMPLER_MAG_FILTER=0x%04x\n", sampler_mag);
        if (contains(gl_extensions, "GL_EXT_texture_filter_anisotropic")) {
            GLfloat sampler_af = 0.0f;
            glSamplerParameterf(sampler, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0f);
            glGetSamplerParameterfv(sampler, GL_TEXTURE_MAX_ANISOTROPY_EXT, &sampler_af);
            printf("RESULT|SAMPLER_AF=%.3f\n", sampler_af);
        } else {
            printf("RESULT|SAMPLER_AF=0\n");
        }
    }

    GLint viewport[4] = {0}, scissor[4] = {0};
    glViewport(7, 11, 123, 137);
    glGetIntegerv(GL_VIEWPORT, viewport);
    glScissor(13, 17, 111, 119);
    glGetIntegerv(GL_SCISSOR_BOX, scissor);
    printf("RESULT|VIEWPORT=%d,%d,%d,%d\n", viewport[0], viewport[1], viewport[2], viewport[3]);
    printf("RESULT|SCISSOR=%d,%d,%d,%d\n", scissor[0], scissor[1], scissor[2], scissor[3]);

    GLint med_range[2] = {0}, med_precision = 0, high_range[2] = {0}, high_precision = 0;
    glGetShaderPrecisionFormat(GL_FRAGMENT_SHADER, GL_MEDIUM_FLOAT, med_range, &med_precision);
    glGetShaderPrecisionFormat(GL_FRAGMENT_SHADER, GL_HIGH_FLOAT, high_range, &high_precision);
    printf("RESULT|MEDIUMP_RANGE=%d,%d\n", med_range[0], med_range[1]);
    printf("RESULT|MEDIUMP_PRECISION=%d\n", med_precision);
    printf("RESULT|HIGHP_RANGE=%d,%d\n", high_range[0], high_range[1]);
    printf("RESULT|HIGHP_PRECISION=%d\n", high_precision);

    const char *fragment_source =
        "#version 300 es\n"
        "precision mediump float;\n"
        "out vec4 fragColor;\n"
        "void main(){ mediump float v=0.1234567; fragColor=vec4(v,v,v,1.0); }\n";
    GLuint shader = glCreateShader(GL_FRAGMENT_SHADER);
    const GLchar *source_ptr = fragment_source;
    glShaderSource(shader, 1, &source_ptr, NULL);
    glCompileShader(shader);
    GLint compiled = 0, info_len = 0;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
    glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &info_len);
    char info[1024] = {0};
    if (info_len > 1) {
        GLsizei written = 0;
        glGetShaderInfoLog(shader, (GLsizei)sizeof(info) - 1, &written, info);
    }
    char returned_source[2048] = {0};
    GLsizei source_len = 0;
    glGetShaderSource(shader, (GLsizei)sizeof(returned_source) - 1, &source_len, returned_source);
    int source_changed = strcmp(fragment_source, returned_source) != 0;
    printf("RESULT|SHADER_COMPILE=%d\n", compiled);
    printf("RESULT|SHADER_SOURCE_CHANGED=%d\n", source_changed);
    printf("RESULT|SHADER_INFO=%s\n", info[0] ? info : "NONE");
    if (shader) glDeleteShader(shader);
    GLenum gl_error = glGetError();
    printf("RESULT|GL_ERROR=0x%04x\n", gl_error);
    printf("RESULT|MODE=%s\n", low_color ? "LOWCOLOR_REQUEST" : "RGBA8888_REQUEST");

    (void)egl_version;
    (void)egl_extensions;
    (void)max_samples;
    return 0;
}
